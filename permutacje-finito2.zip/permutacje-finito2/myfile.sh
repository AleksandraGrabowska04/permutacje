#! /bin/bash

touch pli
echo"Zawartość pliku pli" >> pli
cat pli
